-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 28-Out-2019 às 18:08
-- Versão do servidor: 10.1.36-MariaDB
-- versão do PHP: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `softwarelog`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `gado`
--

CREATE TABLE `gado` (
  `id` int(11) NOT NULL,
  `brincorastreado` varchar(50) NOT NULL,
  `controleinterno` varchar(50) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `raca` varchar(150) NOT NULL,
  `nascimento` varchar(10) NOT NULL,
  `peso` double NOT NULL,
  `genero` varchar(50) NOT NULL,
  `iduser` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `gado`
--

INSERT INTO `gado` (`id`, `brincorastreado`, `controleinterno`, `nome`, `raca`, `nascimento`, `peso`, `genero`, `iduser`) VALUES
(2, '111111', '111111', 'Teste1', 'Raça1', '26/09/2019', 100, 'Macho', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `reports`
--

CREATE TABLE `reports` (
  `id` int(11) NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `erro` varchar(500) NOT NULL,
  `solucionado` varchar(3) DEFAULT 'Não'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `propriedade` varchar(250) NOT NULL,
  `telefone` varchar(15) DEFAULT NULL,
  `email` varchar(150) NOT NULL,
  `senha` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `propriedade`, `telefone`, `email`, `senha`) VALUES
(1, 'Propriedade', '(49)998361049', 'mateusdacruz357@hotmail.com', '123');

-- --------------------------------------------------------

--
-- Estrutura da tabela `vacinalista`
--

CREATE TABLE `vacinalista` (
  `id` int(11) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `iduser` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `vacinalista`
--

INSERT INTO `vacinalista` (`id`, `nome`, `iduser`) VALUES
(1, 'VTeste1', 1),
(2, 'VTeste2', 1),
(3, 'VTeste3', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `vacinas`
--

CREATE TABLE `vacinas` (
  `id` int(11) NOT NULL,
  `nomevacina` varchar(150) NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `idgado` int(11) DEFAULT NULL,
  `datavacinado` varchar(10) DEFAULT NULL,
  `vacinado` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `vacinas`
--

INSERT INTO `vacinas` (`id`, `nomevacina`, `iduser`, `idgado`, `datavacinado`, `vacinado`) VALUES
(10, 'VTeste1', 1, 2, '28/10/2019', 'Sim');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gado`
--
ALTER TABLE `gado`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_iduser` (`iduser`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fkiduser` (`iduser`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `vacinalista`
--
ALTER TABLE `vacinalista`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vacinas`
--
ALTER TABLE `vacinas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gado`
--
ALTER TABLE `gado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `vacinalista`
--
ALTER TABLE `vacinalista`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `vacinas`
--
ALTER TABLE `vacinas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `gado`
--
ALTER TABLE `gado`
  ADD CONSTRAINT `fk_iduser` FOREIGN KEY (`iduser`) REFERENCES `usuarios` (`id`);

--
-- Limitadores para a tabela `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `fkiduser` FOREIGN KEY (`iduser`) REFERENCES `usuarios` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
